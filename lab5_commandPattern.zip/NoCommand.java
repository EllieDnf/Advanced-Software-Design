package Advanced_Software_Design.lab5_commandPattern;


public class NoCommand implements Command {

	@Override
	public void execute() {

	}

	@Override
	public void redo() {

	}

	@Override
	public void undo() {

	}
}
